package com.eustache.api__projet_e_commerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiProjetECommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
