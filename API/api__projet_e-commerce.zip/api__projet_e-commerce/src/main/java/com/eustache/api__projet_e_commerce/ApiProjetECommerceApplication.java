package com.eustache.api__projet_e_commerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiProjetECommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiProjetECommerceApplication.class, args);
	}

}
